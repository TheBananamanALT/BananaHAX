# Minecraft 1.20.4

## Getting Started

To run Minecraft 1.20.4, you will need:

- Java 17 or later installed
- The Minecraft 1.20.4 JAR file

### Downloading the JAR

The Minecraft server JAR can be downloaded from the official Minecraft website:

https://www.minecraft.net/en-us/download/server

Be sure to download the JAR file for version 1.20.4.

### Starting the game

To start the game, open the BananaPRXYtest01.html file, then select the JAR file. Then click:


Play Now


This will start the Minecraft game in a new tab.

The first time you run the game it will lag and keyboard inputs may not work. Stop the game by closing the tab.

Enjoy playing on your new Minecraft 1.20.4 game!